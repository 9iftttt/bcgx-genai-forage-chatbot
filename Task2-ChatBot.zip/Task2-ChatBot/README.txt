Financial Chatbot – README
==========================

Overview
--------
This project is a rule-based, AI-powered financial chatbot for querying company financial data from 2022–2024. The chatbot is built using Python (Flask + Pandas) and provides an interactive, web-based chat interface. The application is designed to help users quickly access, compare, and analyze company financial metrics.

How It Works
------------
- The chatbot reads company financial data from a CSV file (Task1_Summary-Finding.csv).
- Users interact with the chatbot through a modern web UI.
- User questions are interpreted using rule-based logic: the chatbot matches companies, years, and metric keywords, then retrieves the relevant data using Pandas.
- The chatbot displays both the user's questions and its answers in a chat-bubble interface, maintaining conversation history for each session.
- The interface uses a finance-themed color palette and is fully responsive for desktop and mobile.

Supported Queries
-----------------
You can ask about:
- Company revenue, net income, total assets, total liabilities, cash flow, and profit margin for a specific year.
- Growth rates for revenue and net income between two years.
- Whether a company's revenue or net income declined in a given year.

**Example queries:**
- What is Apple’s revenue in 2024?
- What was Microsoft’s net income growth from 2023 to 2024?
- Did Tesla’s revenue decline in 2023?
- What is Tesla’s profit margin in 2022?

How to Update Data
------------------
- Simply edit or replace the file `Task1_Summary-Finding.csv` with updated financial data (keeping the same column names).
- The chatbot will use the new data the next time the app is restarted.

Limitations
-----------
- The chatbot uses rule-based keyword logic, so only questions matching its predefined structure will be answered.
- It does not handle spelling mistakes, unusual synonyms, or conversational follow-up questions.
- Answers are limited to the data in the CSV file; the chatbot does not access live or external sources.
- If a company, year, or metric does not exist in the CSV, the chatbot will respond that no data was found.

How to Run
----------
1. Make sure you have Python 3.8+ installed.
2. Install the dependencies:
    pip install flask pandas
3. Place `app.py`, `Task1_Summary-Finding.csv`, and the `templates` folder (with `index.html`) in the same directory.
4. Start the app:
    python app.py
5. Open your browser and go to:
    http://127.0.0.1:5000/

Credits
-------
- Developed for the BCGx AI/Finance Virtual Internship, 2025.
- Interface design inspired by leading conversational AI platforms.

