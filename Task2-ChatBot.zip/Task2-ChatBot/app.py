import pandas as pd
from flask import Flask, render_template, request, session

app = Flask(__name__)
app.secret_key = '1234567890abcdef'  # Change this to a secure key in production

# Always read the latest CSV
DATA_FILE = "Task1_Summary-Finding.csv"

# Simple utility: load the data each time a query comes in
def load_data():
    df = pd.read_csv(DATA_FILE)
    return df

# Mapping for easier lookup
METRIC_MAP = {
    "revenue": "Total Revenue(Million$)",
    "net income": "Net Income",
    "assets": "Total Assets",
    "liabilities": "Total Liabilities",
    "cash flow": "Cash Flow",
    "revenue growth": "Revenue Growth(%)",
    "net income growth": "Net Income Growth (%)",
    "profit margin": "Profit Margin (%)"
}

def get_bool_col(keyword):
    if "revenue decline" in keyword:
        return "Revenue Decline?"
    if "net income decline" in keyword:
        return "Net Income Decline?"
    return None

# Main response logic
def chatbot_response(user_query):
    user_query = user_query.lower()
    df = load_data()

    # Find company
    companies = df["Company"].str.lower().unique()
    company = next((c for c in companies if c in user_query), None)
    if company: company_row = df[df["Company"].str.lower() == company]
    else: return "Please specify a company (e.g., Apple, Microsoft, Tesla)."

    # Find year(s)
    years = [str(int(y)) for y in company_row["Year"].dropna().unique()]
    year1 = next((y for y in years if y in user_query), None)
    # For growth, look for two years
    import re
    year_matches = re.findall(r"(20\d{2})", user_query)
    year2 = year_matches[1] if len(year_matches) > 1 else None

    # Metric (including growth and booleans)
    metric_key = next((k for k in METRIC_MAP if k in user_query), None)
    bool_key = get_bool_col(user_query)

    # Boolean (decline?) lookup
    if bool_key and year1:
        row = company_row[company_row["Year"] == float(year1)]
        if row.empty:
            return f"No data found for {company.title()} in {year1}."
        val = row.iloc[0][bool_key]
        return f"{company.title()}'s {bool_key.replace('?', '')} in {year1}: {'Yes' if val else 'No'}"

    # Growth metric lookup (from year1 to year2)
    if metric_key and "growth" in metric_key and year1 and year2:
        row1 = company_row[company_row["Year"] == float(year1)]
        row2 = company_row[company_row["Year"] == float(year2)]
        metric_col = METRIC_MAP[metric_key]
        if row1.empty or row2.empty:
            return f"Not enough data to calculate {metric_key.replace('_',' ')} from {year1} to {year2}."
        val1 = row1.iloc[0][metric_col]
        val2 = row2.iloc[0][metric_col]
        try:
            # For percentages, just show the value if it exists
            return (f"{company.title()}'s {metric_col} changed from {val1} in {year1} "
                    f"to {val2} in {year2} "
                    f"({float(val2) - float(val1):+.2f} units difference).")
        except:
            return "Could not compute the growth value."

    # Single-metric lookup
    if metric_key and year1:
        metric_col = METRIC_MAP[metric_key]
        row = company_row[company_row["Year"] == float(year1)]
        if row.empty:
            return f"No data found for {company.title()} in {year1}."
        val = row.iloc[0][metric_col]
        # Format value with commas and no decimals if it's a number
        try:
            formatted_val = f"{val:,.0f}$" if isinstance(val, (int, float)) else f"{val}$"
        except:
            formatted_val = f"{val}$"
        return f"{company.title()}'s {metric_col} in {year1} was {formatted_val}."

    # If only company is mentioned, offer options
    if company and not year1:
        return f"Please specify the year for {company.title()} (e.g., 2023, 2024)."

    return ("Sorry, I can only answer questions about specific companies, years, "
            "and standard metrics such as revenue, growth, and profit margin.")




@app.route("/", methods=["GET", "POST"])
def index():
    if "history" not in session:
        session["history"] = []
    history = session["history"]

    if request.method == "POST":
        user_input = request.form["user_input"]
        bot_reply = chatbot_response(user_input)

        # Append both user and bot messages to history
        history.append({"role": "user", "text": user_input})
        history.append({"role": "bot", "text": bot_reply})
        session["history"] = history

    return render_template("index.html", history=history)

if __name__ == "__main__":
    app.run(debug=True)
